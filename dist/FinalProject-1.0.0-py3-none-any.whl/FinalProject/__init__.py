"""Top-level package for package_name."""

__author__ = "David Cruz Gómez"
__email__ = "david97torrejon@alumnos.cei.es"
__version__ = "1.0.0"

PACKAGE_NAME = "FinalProject"
